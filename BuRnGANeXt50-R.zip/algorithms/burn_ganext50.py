import torch
import torch.nn as nn
import torchvision.models as models

class BuRnGANeXt50(nn.Module):
    def __init__(self, num_classes=3):
        super(BuRnGANeXt50, self).__init__()
        self.model = models.resnext50_32x4d(pretrained=True)
        self.model.fc = nn.Sequential(
            nn.Linear(self.model.fc.in_features, 512),
            nn.ReLU(),
            nn.Linear(512, num_classes)
        )

    def forward(self, x):
        return self.model(x)

if __name__ == "__main__":
    model = BuRnGANeXt50()
    print(model)
