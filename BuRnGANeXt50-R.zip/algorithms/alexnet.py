import torch
import torch.nn as nn
import torchvision.models as models

class AlexNetBurnClassifier(nn.Module):
    def __init__(self, num_classes=3):
        super(AlexNetBurnClassifier, self).__init__()
        self.model = models.alexnet(pretrained=True)
        self.model.classifier[6] = nn.Linear(4096, num_classes)

    def forward(self, x):
        return self.model(x)

if __name__ == "__main__":
    model = AlexNetBurnClassifier()
    print(model)
