import torch
import torch.nn as nn
import torchvision.models as models

class ResNeXtBurnClassifier(nn.Module):
    def __init__(self, num_classes=3):
        super(ResNeXtBurnClassifier, self).__init__()
        self.model = models.resnext50_32x4d(pretrained=True)
        self.model.fc = nn.Linear(self.model.fc.in_features, num_classes)

    def forward(self, x):
        return self.model(x)

if __name__ == "__main__":
    model = ResNeXtBurnClassifier()
    print(model)
